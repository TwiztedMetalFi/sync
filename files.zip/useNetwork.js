import { useNetwork, useSwitchNetwork } from 'wagmi';

export function NetworkSwitcher() {
  const { chain } = useNetwork();
  const { chains, switchNetwork } = useSwitchNetwork();

  return (
    <div>
      <div>Current network: {chain?.name}</div>
      {chains.map((x) => (
        <button key={x.id} onClick={() => switchNetwork?.(x.id)}>
          Switch to {x.name}
        </button>
      ))}
    </div>
  );
}