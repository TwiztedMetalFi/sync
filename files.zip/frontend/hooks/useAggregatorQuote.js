import { useState } from "react";

export function useAggregatorQuote(fromToken, toToken, amount, chainId) {
  const [quote, setQuote] = useState(null);

  async function fetchQuote() {
    const res = await fetch(
      `https://api.1inch.io/v5.0/${chainId}/quote?fromTokenAddress=${fromToken}&toTokenAddress=${toToken}&amount=${amount}`
    );
    setQuote(await res.json());
  }

  return { quote, fetchQuote };
}