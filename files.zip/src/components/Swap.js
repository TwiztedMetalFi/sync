import { useState } from "react";
import { useAccount, usePrepareContractWrite, useContractWrite } from "wagmi";
import ExchangeABI from "../abi/Exchange.json";

export function Swap({ contractAddress }) {
  const [ethAmount, setEthAmount] = useState("0.01");
  const { address } = useAccount();
  const { config } = usePrepareContractWrite({
    address: contractAddress,
    abi: ExchangeABI,
    functionName: "swapEthForToken",
    overrides: { value: BigInt(parseFloat(ethAmount) * 1e18) }
  });
  const { write, isLoading, isSuccess } = useContractWrite(config);

  return (
    <div>
      <input
        value={ethAmount}
        onChange={e => setEthAmount(e.target.value)}
        placeholder="ETH amount"
      />
      <button disabled={!write || isLoading} onClick={() => write?.()}>
        Swap ETH for Token
      </button>
      {isSuccess && <div>Swap successful!</div>}
    </div>
  );
}