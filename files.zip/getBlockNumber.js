const { ethers } = require("ethers");

async function main() {
  const provider = new ethers.JsonRpcProvider('https://rpc.buildbear.io/skilled-northstar-6b42d286');
  try {
    const blockNumber = await provider.getBlockNumber();
    console.log("Current block number:", blockNumber);
  } catch (err) {
    console.error("Error fetching block number:", err);
  }
}

main();